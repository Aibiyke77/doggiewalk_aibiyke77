package com.example.doggiewalk_aibiyke6.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doggiewalk_aibiyke6.Model.Dog;
import com.example.doggiewalk_aibiyke6.R;

import java.util.ArrayList;
import java.util.List;

public class DogsFragment extends Fragment {

    private RecyclerView recyclerView;
    private DogsAdapter adapter;
    private List<Dog> dogList;

    public DogsFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dogs, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_dogs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        dogList = new ArrayList<>();

        dogList.add(new Dog(R.drawable.dog1, "Феликс" ,"Порода: Ретривер\nВозраст: 2 года\n500 сом/в час\nПарк: Ынтымак", "Телефон: +996 705 240 205"));
        dogList.add(new Dog(R.drawable.dog2,"Бобик", "Порода: Корги\nВозраст: 3 года\n500 сом/в час\nПарк: Победы", "Телефон: +996 555 120 502"));
        dogList.add(new Dog(R.drawable.dog3, "Бим","Порода: Доберман\nВозраст: 1 год\n500 сом/в час\nПарк: Дзержинка", "Телефон: +996 555 777 888"));
        dogList.add(new Dog(R.drawable.dog4,"Джек", "Порода: Сибирский хаски\nВозраст: 4 года\n500 сом/в час\nПарк: Ата-Тюрк", "Телефон: +996 555 122 522"));
        dogList.add(new Dog(R.drawable.dog5, "Лорд","Порода: Далматин\nВозраст: 5 лет\n500 сом/в час\nПарк: Дубовый", "Телефон: +996 703 121 592"));
        dogList.add(new Dog(R.drawable.dog6,"Зевс", "Порода: Кавказская овчарка\nВозраст: 3 года\n500 сом/в час\nПарк: Ореховая роща", "Телефон: +996 222 444 999"));
        dogList.add(new Dog(R.drawable.dog7, "Боб","Порода: Американский питбультерьер\nВозраст: 6 лет\n500 сом/в час\nПарк: Адинай", "Телефон: +996 111 111 111"));
        dogList.add(new Dog(R.drawable.dog8, "Герда","Порода: Алабай\nВозраст: 1 год\n500 сом/в час\nПарк: им.Фучика", "Телефон: +996 777 777 777"));
        dogList.add(new Dog(R.drawable.dog9, "Дэнни","Порода: Лайка\nВозраст: 6 месяцев\n500 сом/в час\nПарк: им.Горькова. М", "Телефон: +996 333 111 111"));
        dogList.add(new Dog(R.drawable.dog10,"Тобик", "Порода: Такса\nВозраст: 2 года\n500 сом/в час\nПарк: Любви", "Телефон: +996 888 222 000"));
        dogList.add(new Dog(R.drawable.dog11, "Бумер","Порода: Немецкая овчарка\nВозраст: 4 года\n500 сом/в час\nПарк: Березовая роща", "Телефон: +996 222 111 222"));
        dogList.add(new Dog(R.drawable.dog12,"Рекс", "Порода: Ротвейлер\nВозраст: 5 месяцев\n500 сом/в час\nСквер: им.Тоголок. М", "Телефон: +996 444 444 114"));
        dogList.add(new Dog(R.drawable.dog13,"Шелли", "Порода: Пудель\nВозраст: 3 года\n500 сом/в час\nПарк: Этно им.Маметова. Б", "Телефон: +996 333 999 010"));
        dogList.add(new Dog(R.drawable.dog14,"Фабби", "Порода: Маламут\nВозраст: 7 лет\n500 сом/в час\nПарк: Ак-Орго", "Телефон: +996 911 788 244"));
        dogList.add(new Dog(R.drawable.dog15,"Фрося", "Порода: Колли\nВозраст: 1 год\n500 сом/в час\nПарк: Аллея журналистов", "Телефон: +996 666 666 667"));


        adapter = new DogsAdapter(dogList, getActivity());
        recyclerView.setAdapter(adapter);

        return view;
    }
}







