package com.example.doggiewalk_aibiyke6;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.doggiewalk_aibiyke6.ui.Feedback.FeedbackFragment;
import com.example.doggiewalk_aibiyke6.ui.dashboard.DogsFragment;
import com.example.doggiewalk_aibiyke6.ui.home.HomeFragment;
import com.example.doggiewalk_aibiyke6.ui.notifications.PaymentFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navView = findViewById(R.id.nav_view);

        navView.setOnNavigationItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                selectedFragment = new HomeFragment();
            } else if (itemId == R.id.navigation_dogs) {
                selectedFragment = new DogsFragment();
            } else if (itemId == R.id.navigation_payment) {
                selectedFragment = new PaymentFragment();
            } else if (itemId == R.id.navigation_feedback) {
                selectedFragment = new FeedbackFragment();
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nav_host_fragment, selectedFragment)
                        .commit();
            }
            return true;
        });

        if (savedInstanceState == null) {
            navView.setSelectedItemId(R.id.navigation_home);
        }
    }
}


