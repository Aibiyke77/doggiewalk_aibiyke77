package com.example.doggiewalk_aibiyke6.ui.dashboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doggiewalk_aibiyke6.Model.Dog;
import com.example.doggiewalk_aibiyke6.R;

import java.util.List;

public class DogsAdapter extends RecyclerView.Adapter<DogsAdapter.ViewHolder> {

    private List<Dog> dogsList;
    private Context context;

    public DogsAdapter(List<Dog> dogsList, Context context) {
        this.dogsList = dogsList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.dog_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Dog dog = dogsList.get(position);

        holder.imageViewDog.setImageResource(dog.getImageResource());
        holder.textViewName.setText(dog.getName());
        holder.textViewDetails.setText(dog.getDetails());
        holder.textViewPhone.setText(dog.getPhone());
    }

    @Override
    public int getItemCount() {
        return dogsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageViewDog;
        TextView textViewName;
        TextView textViewDetails;
        TextView textViewPhone;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewDog = itemView.findViewById(R.id.image_view_dog);
            textViewName = itemView.findViewById(R.id.text_view_name);
            textViewDetails = itemView.findViewById(R.id.text_view_details);
            textViewPhone = itemView.findViewById(R.id.text_view_phone);
        }
    }
}

